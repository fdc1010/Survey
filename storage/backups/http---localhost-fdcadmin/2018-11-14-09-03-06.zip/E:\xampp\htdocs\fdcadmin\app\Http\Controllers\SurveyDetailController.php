<?php

namespace App\Http\Controllers;

use App\SurveyDetail;
use Illuminate\Http\Request;

class SurveyDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SurveyDetail  $surveyDetail
     * @return \Illuminate\Http\Response
     */
    public function show(SurveyDetail $surveyDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SurveyDetail  $surveyDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(SurveyDetail $surveyDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SurveyDetail  $surveyDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SurveyDetail $surveyDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SurveyDetail  $surveyDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(SurveyDetail $surveyDetail)
    {
        //
    }
}
