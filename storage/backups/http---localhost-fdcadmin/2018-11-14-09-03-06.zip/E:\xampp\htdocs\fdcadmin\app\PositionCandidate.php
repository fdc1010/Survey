<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PositionCandidate extends Model
{
    //
}
