<?php

namespace App\Http\Controllers;

use App\Models\Precinct;
use Illuminate\Http\Request;

class PrecinctController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Precinct  $precinct
     * @return \Illuminate\Http\Response
     */
    public function show(Precinct $precinct)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Precinct  $precinct
     * @return \Illuminate\Http\Response
     */
    public function edit(Precinct $precinct)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Precinct  $precinct
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Precinct $precinct)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Precinct  $precinct
     * @return \Illuminate\Http\Response
     */
    public function destroy(Precinct $precinct)
    {
        //
    }
}
